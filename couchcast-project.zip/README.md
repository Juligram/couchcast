# Couchcast (Android app)

Streams video, music and the camera from one phone to a tablet over Wi-Fi.
The app has its own small server built in, so nothing else needs to be installed.

- `app/src/main/assets/index.html` is the Couchcast page.
- `app/src/main/java/app/couchcast/RelayServer.java` is the built-in server (the same job as `serve.py`).
- `.github/workflows/build.yml` builds the app online. Each push to `main` makes a new
  release with `couchcast.apk` attached.
