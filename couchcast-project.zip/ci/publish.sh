#!/usr/bin/env bash
set -e
cp app/build/outputs/apk/release/app-release.apk couchcast.apk
gh release create "build-${GITHUB_RUN_NUMBER}-${GITHUB_RUN_ATTEMPT}" couchcast.apk \
  --target "${GITHUB_SHA}" \
  --title "Couchcast build ${GITHUB_RUN_NUMBER}" \
  --notes "Download couchcast.apk below and install it on the phone." \
  --latest
