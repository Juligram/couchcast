#!/usr/bin/env bash
set -o pipefail
gradle --no-daemon --console=plain assembleRelease 2>&1 | tee build.log
