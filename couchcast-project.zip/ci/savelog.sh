#!/usr/bin/env bash
# Keeps the build log on a side branch so problems can be read and fixed quickly.
cp build.log /tmp/build.log 2>/dev/null || echo "no build log" > /tmp/build.log
git config user.name "github-actions[bot]"
git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
git checkout --orphan buildlog
git rm -rf --quiet . || true
cp /tmp/build.log build.log
echo "run ${GITHUB_RUN_NUMBER} commit ${GITHUB_SHA} status ${STATUS}" > status.txt
git add build.log status.txt
git commit -q -m "Build log for run ${GITHUB_RUN_NUMBER}"
git push -f origin buildlog
