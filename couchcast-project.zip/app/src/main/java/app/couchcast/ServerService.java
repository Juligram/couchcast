package app.couchcast;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Keeps Couchcast's server alive while you use other apps, and shows the
 * notification with its Stop button. The server itself is shared with the
 * screen (same process), so it is started by whichever of the two comes first.
 */
public class ServerService extends Service {
    static final String ACTION_STOP = "app.couchcast.STOP";
    private static final String CHANNEL = "couchcast_server";
    private static final int NOTIFICATION_ID = 1;

    private static RelayServer server;
    private static byte[] pageBytes;

    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;

    /** Starts the server if it is not running yet and returns its port. */
    static synchronized int ensureServer(Context context) throws IOException {
        if (server == null) {
            final Context app = context.getApplicationContext();
            RelayServer s = new RelayServer(() -> loadPage(app));
            s.start(8000);
            server = s;
        }
        return server.port();
    }

    static synchronized void stopServer() {
        if (server != null) {
            server.stop();
            server = null;
        }
    }

    private static synchronized byte[] loadPage(Context app) throws IOException {
        if (pageBytes == null) {
            try (InputStream in = app.getAssets().open("index.html")) {
                ByteArrayOutputStream out = new ByteArrayOutputStream(96 * 1024);
                byte[] buf = new byte[16 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                pageBytes = out.toByteArray();
            }
        }
        return pageBytes;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutDown();
            return START_NOT_STICKY;
        }
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIFICATION_ID, n);
            }
        } catch (RuntimeException e) {
            // Could not become a foreground service: the app still works while it is open.
            stopSelf();
            return START_NOT_STICKY;
        }
        acquireLocks();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        releaseLocks();
        super.onDestroy();
    }

    private void shutDown() {
        stopServer();
        releaseLocks();
        stopForeground(true);
        stopSelf();
        // Close the screen too, so the app is really off.
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    private void acquireLocks() {
        try {
            if (wake == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "couchcast:server");
                wake.setReferenceCounted(false);
            }
            if (!wake.isHeld()) wake.acquire(12L * 60 * 60 * 1000);
            if (wifi == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "couchcast:wifi");
                wifi.setReferenceCounted(false);
            }
            if (!wifi.isHeld()) wifi.acquire();
        } catch (RuntimeException e) {
            // Locks are a nicety; streaming still works without them.
        }
    }

    private void releaseLocks() {
        try {
            if (wake != null && wake.isHeld()) wake.release();
            if (wifi != null && wifi.isHeld()) wifi.release();
        } catch (RuntimeException e) {
            // ignore
        }
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(
                new NotificationChannel(CHANNEL, "Couchcast", NotificationManager.IMPORTANCE_LOW));

        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent open = PendingIntent.getActivity(
                this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stopIntent = new Intent(this, ServerService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(
                this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_stat), "Stop", stop).build();

        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Couchcast is running")
                .setContentText("Tap to open. Press Stop to shut it down.")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(stopAction)
                .build();
    }
}
