package app.couchcast;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Shows the Couchcast page (served by the built-in server) full screen. */
public class MainActivity extends Activity {
    private static final int REQ_FILES = 1;
    private static final int REQ_MEDIA = 2;
    private static final int REQ_NOTIFY = 3;

    private WebView web;
    private ValueCallback<Uri[]> chooserCallback;
    private PermissionRequest pendingRequest;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        // The picture is being sent from this screen, so never let it sleep while it is open.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0A1F14"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            // The "choose videos" button.
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*"); // videos, music and subtitle files all in one go
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(pick, REQ_FILES);
                } catch (ActivityNotFoundException e) {
                    chooserCallback = null;
                    callback.onReceiveValue(null);
                }
                return true;
            }

            // Camera and microphone: ask Android first, then tell the page.
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingRequest == request) pendingRequest = null;
            }
        });

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
        }
        startServerAndLoad();
    }

    private void startServerAndLoad() {
        new Thread(() -> {
            int found = 0;
            String problem = null;
            try {
                found = ServerService.ensureServer(MainActivity.this);
            } catch (IOException | RuntimeException e) {
                problem = String.valueOf(e.getMessage());
            }
            final int port = found;
            final String error = problem;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (error != null) {
                    web.loadDataWithBaseURL(null,
                            "<body style='background:#0A1F14;color:#E8F5EC;font:18px sans-serif;padding:24px'>"
                                    + "<h2>Couchcast could not start</h2><p>"
                                    + TextUtils.htmlEncode(error) + "</p></body>",
                            "text/html", "UTF-8", null);
                    return;
                }
                try {
                    // Keeps the server running when you switch to another app.
                    startForegroundService(new Intent(MainActivity.this, ServerService.class));
                } catch (RuntimeException e) {
                    // The server still runs while this screen is open.
                }
                web.loadUrl("http://127.0.0.1:" + port + "/");
            });
        }, "couchcast-start").start();
    }

    // ----- camera / microphone -----

    private boolean has(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean ourPage(PermissionRequest request) {
        String host = request.getOrigin() == null ? null : request.getOrigin().getHost();
        return "127.0.0.1".equals(host) || "localhost".equals(host);
    }

    private void handleWebPermission(PermissionRequest request) {
        if (!ourPage(request)) {
            request.deny();
            return;
        }
        List<String> need = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !has(Manifest.permission.CAMERA)) {
                need.add(Manifest.permission.CAMERA);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !has(Manifest.permission.RECORD_AUDIO)) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
        }
        if (need.isEmpty()) {
            answer(request);
        } else {
            if (pendingRequest != null) pendingRequest.deny();
            pendingRequest = request;
            requestPermissions(need.toArray(new String[0]), REQ_MEDIA);
        }
    }

    /** Lets the page use whichever of camera / microphone Android now allows. */
    private void answer(PermissionRequest request) {
        List<String> ok = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && has(Manifest.permission.CAMERA)) ok.add(r);
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && has(Manifest.permission.RECORD_AUDIO)) ok.add(r);
        }
        if (ok.isEmpty()) request.deny();
        else request.grant(ok.toArray(new String[0]));
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == REQ_MEDIA && pendingRequest != null) {
            PermissionRequest request = pendingRequest;
            pendingRequest = null;
            answer(request);
        }
    }

    // ----- file picker -----

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILES) {
            ValueCallback<Uri[]> callback = chooserCallback;
            chooserCallback = null;
            if (callback != null) {
                Uri[] picked = resultCode == RESULT_OK
                        ? WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                        : null;
                callback.onReceiveValue(picked);
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // ----- lifecycle -----

    @Override
    public void onBackPressed() {
        // Keep everything running; the notification has the Stop button.
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (chooserCallback != null) {
            chooserCallback.onReceiveValue(null);
            chooserCallback = null;
        }
        if (web != null) {
            ViewGroup parent = (ViewGroup) web.getParent();
            if (parent != null) parent.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
