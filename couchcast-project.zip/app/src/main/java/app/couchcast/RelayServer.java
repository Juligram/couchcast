package app.couchcast;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The same small server as serve.py: it hands out the page and passes the pairing
 * messages between the two devices. The video itself never goes through it.
 * Plain Java, no Android classes, so it can be tested on its own.
 */
public final class RelayServer {
    /** Supplies the bytes of index.html. */
    public interface Page {
        byte[] bytes() throws IOException;
    }

    private static final long ROOM_TTL_MS = 6L * 60 * 60 * 1000;
    private static final long POLL_MS = 15000;
    private static final int MAX_BODY = 200000;

    // Browsers hide their LAN address behind a random "xxxxxxxx-....local" name.
    // Some devices cannot resolve those, so the address the request came from is swapped in.
    private static final Pattern MDNS = Pattern.compile(
            "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\\.local");

    private static final class Msg {
        int idx;
        String from;
        String peer;
        String type;
        String sdp;
    }

    private static final class Room {
        final List<Msg> msgs = new ArrayList<>();
        int counter;
        long touched = System.currentTimeMillis();
    }

    private static final class Request {
        String method = "";
        String path = "/";
        String query = "";
        byte[] body = new byte[0];
        boolean tooBig;
    }

    private final Page page;
    private final Map<String, Room> rooms = new HashMap<>();
    private final SecureRandom random = new SecureRandom();
    private volatile List<String> lanOverride;
    private volatile boolean running;
    private volatile int port;
    private ServerSocket socket;
    private ExecutorService pool;

    public RelayServer(Page page) {
        this.page = page;
    }

    /** For tests: pretend these are this device's Wi-Fi addresses. */
    public void setLanOverride(List<String> lan) {
        lanOverride = lan;
    }

    public int port() {
        return port;
    }

    /** Starts listening on the first free port from preferredPort. Returns the port used. */
    public synchronized int start(int preferredPort) throws IOException {
        if (socket != null) return port;
        InetAddress any = InetAddress.getByName("0.0.0.0");
        ServerSocket ss = null;
        for (int p = preferredPort; p < preferredPort + 20; p++) {
            try {
                ss = bind(any, p);
                break;
            } catch (IOException taken) {
                // try the next one
            }
        }
        if (ss == null) ss = bind(any, 0);
        socket = ss;
        port = ss.getLocalPort();
        running = true;
        pool = Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r, "couchcast-conn");
            t.setDaemon(true);
            return t;
        });
        final ServerSocket server = ss;
        Thread t = new Thread(() -> acceptLoop(server), "couchcast-accept");
        t.setDaemon(true);
        t.start();
        return port;
    }

    public synchronized void stop() {
        running = false;
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException ignore) {
                // already closed
            }
            socket = null;
        }
        if (pool != null) {
            pool.shutdownNow();
            pool = null;
        }
        port = 0;
    }

    private static ServerSocket bind(InetAddress addr, int port) throws IOException {
        ServerSocket ss = new ServerSocket();
        try {
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(addr, port));
            return ss;
        } catch (IOException e) {
            try {
                ss.close();
            } catch (IOException ignore) {
                // nothing to do
            }
            throw e;
        }
    }

    private void acceptLoop(ServerSocket server) {
        while (running) {
            try {
                final Socket c = server.accept();
                ExecutorService p = pool;
                if (p == null) {
                    c.close();
                    break;
                }
                p.execute(() -> serve(c));
            } catch (IOException e) {
                if (!running) break;
                try {
                    Thread.sleep(50);
                } catch (InterruptedException ie) {
                    break;
                }
            } catch (RuntimeException e) {
                break;
            }
        }
    }

    // ----- network addresses -----

    /** This device's Wi-Fi / hotspot / ethernet addresses, Wi-Fi first. */
    public List<String> lan() {
        List<String> o = lanOverride;
        return o != null ? o : lanAddresses();
    }

    static List<String> lanAddresses() {
        List<String> first = new ArrayList<>();
        List<String> rest = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String name = ni.getName().toLowerCase(Locale.ROOT);
                if (name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("tun")
                        || name.startsWith("dummy") || name.startsWith("p2p") || name.startsWith("v4-")
                        || name.startsWith("ipsec") || name.startsWith("tap") || name.startsWith("lo")) {
                    continue;
                }
                boolean preferred = name.startsWith("wlan") || name.startsWith("eth") || name.startsWith("swlan")
                        || name.startsWith("ap") || name.startsWith("wigig");
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress() || a.isLinkLocalAddress()) continue;
                    String ip = a.getHostAddress();
                    // Wi-Fi, hotspot and cable addresses are used as they are; anything else
                    // (USB tethering, ...) only when it is a normal home-network address.
                    if (!preferred && !a.isSiteLocalAddress()) continue;
                    List<String> dest = preferred ? first : rest;
                    if (!dest.contains(ip)) dest.add(ip);
                }
            }
        } catch (Exception e) {
            // no network information available
        }
        first.addAll(rest);
        return first;
    }

    private String clientIp(Socket c) {
        List<String> lan = lan();
        InetAddress a = c.getInetAddress();
        // A device that opened the page as "localhost" (the phone running this app)
        // must be reachable by the others on its Wi-Fi address, not by 127.0.0.1.
        if (a.isLoopbackAddress() && !lan.isEmpty()) return lan.get(0);
        String ip = a.getHostAddress();
        int pct = ip.indexOf('%');
        if (pct >= 0) ip = ip.substring(0, pct);
        if (ip.startsWith("::ffff:")) ip = ip.substring(7);
        return ip;
    }

    // ----- one connection -----

    private void serve(Socket s) {
        try (Socket c = s) {
            c.setSoTimeout(20000); // time allowed for the browser to send its request
            c.setTcpNoDelay(true);
            InputStream in = new BufferedInputStream(c.getInputStream());
            OutputStream out = c.getOutputStream();
            Request r = readRequest(in);
            if (r == null) return;
            c.setSoTimeout(0);
            route(r, c, out);
        } catch (IOException | RuntimeException e) {
            // the other side went away
        }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        while (true) {
            int c = in.read();
            if (c < 0) return sb.length() == 0 ? null : sb.toString();
            if (c == '\n') {
                int n = sb.length();
                if (n > 0 && sb.charAt(n - 1) == '\r') sb.setLength(n - 1);
                return sb.toString();
            }
            if (sb.length() > 16384) throw new IOException("line too long");
            sb.append((char) c);
        }
    }

    private static Request readRequest(InputStream in) throws IOException {
        String line = readLine(in);
        if (line == null || line.isEmpty()) return null;
        String[] p = line.split(" ");
        if (p.length < 2) return null;
        Request r = new Request();
        r.method = p[0];
        String target = p[1];
        int q = target.indexOf('?');
        if (q >= 0) {
            r.query = target.substring(q + 1);
            target = target.substring(0, q);
        }
        r.path = target;
        int len = 0;
        for (int n = 0; n < 100; n++) {
            String h = readLine(in);
            if (h == null) return null;
            if (h.isEmpty()) break;
            int c = h.indexOf(':');
            if (c > 0 && h.substring(0, c).trim().equalsIgnoreCase("content-length")) {
                try {
                    len = Integer.parseInt(h.substring(c + 1).trim());
                } catch (NumberFormatException e) {
                    len = 0;
                }
            }
        }
        if (len > MAX_BODY) {
            r.tooBig = true;
        } else if (len > 0) {
            byte[] b = new byte[len];
            int got = 0;
            while (got < len) {
                int k = in.read(b, got, len - got);
                if (k < 0) return null;
                got += k;
            }
            r.body = b;
        }
        return r;
    }

    private static Map<String, String> parseQuery(String q) {
        Map<String, String> m = new HashMap<>();
        for (String kv : q.split("&")) {
            if (kv.isEmpty()) continue;
            int e = kv.indexOf('=');
            String k = e < 0 ? kv : kv.substring(0, e);
            String v = e < 0 ? "" : kv.substring(e + 1);
            try {
                String key = URLDecoder.decode(k, "UTF-8");
                if (!m.containsKey(key)) m.put(key, URLDecoder.decode(v, "UTF-8"));
            } catch (Exception bad) {
                // skip undecodable pairs
            }
        }
        return m;
    }

    private static String reason(int status) {
        switch (status) {
            case 200: return "OK";
            case 400: return "Bad Request";
            case 404: return "Not Found";
            case 500: return "Internal Server Error";
            case 503: return "Service Unavailable";
            default: return "Status";
        }
    }

    private static void send(OutputStream out, int status, String ctype, byte[] body) throws IOException {
        String head = "HTTP/1.1 " + status + " " + reason(status) + "\r\n"
                + "Content-Type: " + ctype + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.ISO_8859_1));
        out.write(body);
        out.flush();
    }

    private static void sendJson(OutputStream out, int status, String json) throws IOException {
        send(out, status, "application/json", json.getBytes(StandardCharsets.UTF_8));
    }

    // ----- routes -----

    private void route(Request r, Socket c, OutputStream out) throws IOException {
        String[] parts = r.path.replaceAll("^/+|/+$", "").split("/");
        boolean roomPath = parts.length >= 3 && parts[0].equals("api") && parts[1].equals("rooms");

        if (r.method.equals("GET")) {
            if (r.path.equals("/") || r.path.equals("/index.html")) {
                byte[] html;
                try {
                    html = page.bytes();
                } catch (IOException e) {
                    send(out, 500, "text/plain", "index.html is missing".getBytes(StandardCharsets.UTF_8));
                    return;
                }
                send(out, 200, "text/html; charset=utf-8", html);
                return;
            }
            if (r.path.equals("/api/ping")) {
                StringBuilder b = new StringBuilder("{\"ok\":true,\"lan\":[");
                List<String> lan = lan();
                for (int k = 0; k < lan.size(); k++) {
                    if (k > 0) b.append(',');
                    b.append(Json.quote(lan.get(k)));
                }
                sendJson(out, 200, b.append("]}").toString());
                return;
            }
            if (roomPath && parts.length == 4 && parts[3].equals("poll")) {
                Room room = findRoom(parts[2]);
                if (room == null) {
                    sendJson(out, 404, "{\"error\":\"no such room\"}");
                    return;
                }
                Map<String, String> q = parseQuery(r.query);
                String role = q.containsKey("role") ? q.get("role") : "guest";
                String peer = q.containsKey("peer") ? q.get("peer") : "";
                int after = 0;
                try {
                    after = Integer.parseInt(q.containsKey("after") ? q.get("after") : "0");
                } catch (NumberFormatException e) {
                    after = 0;
                }
                poll(room, role, peer, after, out);
                return;
            }
        } else if (r.method.equals("POST")) {
            if (r.path.replaceAll("/+$", "").equals("/api/rooms")) {
                String code = newRoom();
                if (code == null) sendJson(out, 503, "{\"error\":\"too many rooms\"}");
                else sendJson(out, 200, "{\"code\":" + Json.quote(code) + "}");
                return;
            }
            if (roomPath && parts.length == 4 && parts[3].equals("msg")) {
                Room room = findRoom(parts[2]);
                if (room == null) {
                    sendJson(out, 404, "{\"error\":\"no such room\"}");
                    return;
                }
                postMessage(room, r, c, out);
                return;
            }
        } else if (r.method.equals("DELETE")) {
            if (roomPath && parts.length == 3) {
                synchronized (rooms) {
                    rooms.remove(parts[2]);
                }
                sendJson(out, 200, "{\"ok\":true}");
                return;
            }
        }
        sendJson(out, 404, "{\"error\":\"not found\"}");
    }

    private Room findRoom(String code) {
        synchronized (rooms) {
            return rooms.get(code);
        }
    }

    private String newRoom() {
        long now = System.currentTimeMillis();
        synchronized (rooms) {
            List<String> old = new ArrayList<>();
            for (Map.Entry<String, Room> e : rooms.entrySet()) {
                if (now - e.getValue().touched > ROOM_TTL_MS) old.add(e.getKey());
            }
            for (String k : old) rooms.remove(k);
            for (int n = 0; n < 200; n++) {
                String code = String.format(Locale.ROOT, "%04d", random.nextInt(10000));
                if (!rooms.containsKey(code)) {
                    rooms.put(code, new Room());
                    return code;
                }
            }
        }
        return null;
    }

    private static String cut(Object o, int max) {
        String s = o == null ? "" : String.valueOf(o);
        return s.length() > max ? s.substring(0, max) : s;
    }

    @SuppressWarnings("unchecked")
    private void postMessage(Room room, Request r, Socket c, OutputStream out) throws IOException {
        Object parsed = null;
        if (!r.tooBig) {
            try {
                parsed = Json.parse(new String(r.body, StandardCharsets.UTF_8));
            } catch (IllegalArgumentException bad) {
                parsed = null;
            }
        }
        if (!(parsed instanceof Map)) {
            sendJson(out, 400, "{\"error\":\"bad message\"}");
            return;
        }
        Map<String, Object> body = (Map<String, Object>) parsed;
        Object from = body.get("from");
        if (!"host".equals(from) && !"guest".equals(from)) {
            sendJson(out, 400, "{\"error\":\"bad message\"}");
            return;
        }
        Msg m = new Msg();
        m.from = (String) from;
        m.peer = cut(body.get("peer"), 32);
        m.type = cut(body.get("type"), 16);
        Object sdp = body.get("sdp");
        if (sdp instanceof String) {
            m.sdp = MDNS.matcher((String) sdp).replaceAll(Matcher.quoteReplacement(clientIp(c)));
        }
        synchronized (room) {
            room.counter++;
            m.idx = room.counter;
            room.msgs.add(m);
            while (room.msgs.size() > 200) room.msgs.remove(0);
            room.touched = System.currentTimeMillis();
            room.notifyAll();
        }
        sendJson(out, 200, "{\"ok\":true}");
    }

    private static String msgJson(Msg m) {
        StringBuilder b = new StringBuilder("{\"from\":").append(Json.quote(m.from))
                .append(",\"peer\":").append(Json.quote(m.peer))
                .append(",\"type\":").append(Json.quote(m.type));
        if (m.sdp != null) b.append(",\"sdp\":").append(Json.quote(m.sdp));
        return b.append(",\"idx\":").append(m.idx).append('}').toString();
    }

    /** Waits up to 15 seconds for a message addressed to this device, then answers. */
    private void poll(Room room, String role, String peer, int after, OutputStream out) throws IOException {
        long deadline = System.currentTimeMillis() + POLL_MS;
        List<Msg> found = new ArrayList<>();
        int last;
        synchronized (room) {
            while (true) {
                room.touched = System.currentTimeMillis();
                last = Math.max(after, room.msgs.isEmpty() ? 0 : room.msgs.get(room.msgs.size() - 1).idx);
                found.clear();
                for (Msg m : room.msgs) {
                    if (m.idx <= after) continue;
                    if (role.equals("host")) {
                        if (m.from.equals("guest")) found.add(m);
                    } else if (m.from.equals("host") && m.peer.equals(peer)) {
                        found.add(m);
                    }
                }
                long remaining = deadline - System.currentTimeMillis();
                if (!found.isEmpty() || remaining <= 0) break;
                try {
                    room.wait(remaining);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        StringBuilder b = new StringBuilder("{\"msgs\":[");
        for (int k = 0; k < found.size(); k++) {
            if (k > 0) b.append(',');
            b.append(msgJson(found.get(k)));
        }
        b.append("],\"last\":").append(last).append('}');
        sendJson(out, 200, b.toString());
    }
}
