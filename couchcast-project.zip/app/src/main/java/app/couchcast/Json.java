package app.couchcast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** A very small JSON reader/writer, just enough for the relay's pairing messages. */
final class Json {
    private final String s;
    private int i;

    private Json(String s) {
        this.s = s;
    }

    /** Returns a Map, List, String, Double, Boolean or null. Throws IllegalArgumentException on bad input. */
    static Object parse(String text) {
        Json p = new Json(text);
        p.skip();
        Object v = p.value(0);
        p.skip();
        if (p.i != p.s.length()) throw bad();
        return v;
    }

    static String quote(String v) {
        StringBuilder b = new StringBuilder(v.length() + 2);
        b.append('"');
        for (int k = 0; k < v.length(); k++) {
            char c = v.charAt(k);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20) b.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        return b.append('"').toString();
    }

    private static IllegalArgumentException bad() {
        return new IllegalArgumentException("bad json");
    }

    private void skip() {
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') i++;
            else break;
        }
    }

    private char peek() {
        if (i >= s.length()) throw bad();
        return s.charAt(i);
    }

    private Object value(int depth) {
        if (depth > 32) throw bad();
        char c = peek();
        if (c == '{') return object(depth);
        if (c == '[') return array(depth);
        if (c == '"') return string();
        if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
        if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
        if (s.startsWith("null", i)) { i += 4; return null; }
        return number();
    }

    private Map<String, Object> object(int depth) {
        Map<String, Object> m = new LinkedHashMap<>();
        i++;
        skip();
        if (peek() == '}') { i++; return m; }
        while (true) {
            skip();
            if (peek() != '"') throw bad();
            String k = string();
            skip();
            if (peek() != ':') throw bad();
            i++;
            skip();
            m.put(k, value(depth + 1));
            skip();
            char c = peek();
            i++;
            if (c == '}') return m;
            if (c != ',') throw bad();
        }
    }

    private List<Object> array(int depth) {
        List<Object> a = new ArrayList<>();
        i++;
        skip();
        if (peek() == ']') { i++; return a; }
        while (true) {
            skip();
            a.add(value(depth + 1));
            skip();
            char c = peek();
            i++;
            if (c == ']') return a;
            if (c != ',') throw bad();
        }
    }

    private String string() {
        StringBuilder b = new StringBuilder();
        i++; // opening quote
        while (true) {
            char c = peek();
            i++;
            if (c == '"') return b.toString();
            if (c != '\\') { b.append(c); continue; }
            char e = peek();
            i++;
            switch (e) {
                case '"': b.append('"'); break;
                case '\\': b.append('\\'); break;
                case '/': b.append('/'); break;
                case 'b': b.append('\b'); break;
                case 'f': b.append('\f'); break;
                case 'n': b.append('\n'); break;
                case 'r': b.append('\r'); break;
                case 't': b.append('\t'); break;
                case 'u':
                    if (i + 4 > s.length()) throw bad();
                    b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                    i += 4;
                    break;
                default:
                    throw bad();
            }
        }
    }

    private Double number() {
        int start = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        if (start == i) throw bad();
        return Double.valueOf(s.substring(start, i));
    }
}
